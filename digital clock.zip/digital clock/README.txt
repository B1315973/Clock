It is Digital Clock Designed Jogarao
